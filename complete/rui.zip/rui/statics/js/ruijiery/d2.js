
$(window).load(function() {
        
    $(".diamondswrap").diamonds({
        size: 160, // Size of the squares
        gap: 7// Pixels between squares
    });
});